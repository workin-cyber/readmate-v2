// import styles from './style.module.css'
import './style.css'

// Creator : Team A - Shahar
function Temp(){
    return <>
    
    </>
}


export default Temp