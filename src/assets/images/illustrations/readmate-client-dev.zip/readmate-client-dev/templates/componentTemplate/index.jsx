import styles from './style.module.css'

// Creator : Team A - Shahar
function Temp(){
    return <div className='graf'>

    </div>
    
   
}


export default Temp