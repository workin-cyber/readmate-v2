// import styles from './style.module.css'

// Creator : Team A - Shahar
function Context({ children }) {
    return <>
        {children}
    </>
}


export default Context