import { createContext } from "react";

export const dataContext = createContext();

//---נא לקבל שינויים של קונטקטס לpopup
export const popupContext = createContext();