import React from 'react'

export default function Lpm() {
  return (
    <div className='Tab'>Lpm</div>
  )
}
