// import Clock from '../../common/Clock'
// import GraphDashboard from '../../common/graphDashboard'
import Instructions from '../../../pages/FreeStyle/Instructions'
function TeamH() {
    return (
        <>
            <div>TeamH</div>
            {/* <GraphDashboard></GraphDashboard> */}
            <Instructions></Instructions>
            {/* <Clock>milka:</Clock> */}


        </>


    )
}

export default TeamH