import React from 'react'

export default function Focus() {
  return (
    <div className='Tab'>Focus</div>
  )
}
