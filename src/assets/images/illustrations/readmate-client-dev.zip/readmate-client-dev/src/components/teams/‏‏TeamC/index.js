import React from 'react'
import TextArea from '../../common/TextArea'


const index = () => {
    return (
        <div>
            <TextArea />
        </div>
    )
}

export default index
