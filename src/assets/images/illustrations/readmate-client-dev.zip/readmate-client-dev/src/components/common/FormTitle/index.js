import "./style.css";

import React from "react";
// Creator : Team D - Dov
export const FormTitle = () => {
  return (
    <div className="FormTitle">
      <div className="title">Create an Account</div>
    </div>
  );
};

export default FormTitle;
