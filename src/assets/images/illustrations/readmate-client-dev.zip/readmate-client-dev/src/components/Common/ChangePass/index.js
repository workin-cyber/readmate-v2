// import {Link} from "react-router-dom"
import "./style.css"  

export default function ChangePass(){
    return(
       <div className="note">Change Password</div>
    )
}