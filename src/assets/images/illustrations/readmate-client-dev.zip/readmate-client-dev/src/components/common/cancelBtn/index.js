import styles from './style.module.css'


// Creator : Team F - Asael

function CancelBtn() {
        
        return(
        <div>
                <button  type="button" className={`${styles.frame7}`} >Cancel</button>
        </div>)
};

export default CancelBtn