import styles from './style.module.css'


// Creator : Team F - Asael

function TrueBtn() {
        
        return(
        <div>
                <button  type="button" className={`${styles.frame8}`} >True</button>
        </div>)
};

export default TrueBtn