import React from 'react'

function SelectPeriod(props){

  function detectChange(v) {
    const val = v.target.value;
    props.updatePeriod(val)
  }
  return <>
  <select name="readtime" id="readtime" onChange={(v)=>detectChange(v)}>
  <option value="today"> Today </option>
  <option selected value="lastWeek"> Last week </option>
  <option value="twoWeeks"> 2 weeks </option>
  <option value="month"> Month </option>
  </select> 
 
  </>
}


export default SelectPeriod
