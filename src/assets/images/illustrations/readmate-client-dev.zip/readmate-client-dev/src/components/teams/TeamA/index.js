import Page1 from "../../../pages/Assessments/Page1"
import Page3 from "../../../pages/Assessments/Page3"
import Page4 from "../../../pages/Assessments/Page4"
// import Page5 from "../../../pages/Assessments/Page5"
import Page6 from "../../../pages/Assessments/Page6"
function TeamA() {
    return (
        <div>
            <Page1 />

        </div>
    )
}

export default TeamA