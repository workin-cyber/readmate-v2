import React from 'react'
import Focus from './Focus'
import Graph from './Graph'
import Lpm from './Lpm'
import SelectPeriod from './SelectPeriod'
import Wpm from './Wpm'
import './Style.css'

export default function GraphCont() {
  return (
    <div className='GGG'>
        <div className='Tabs'>
        <Wpm />
        <Lpm />
        <Focus />
        </div>
        <SelectPeriod />
        <Graph />
    </div>
  )
}
