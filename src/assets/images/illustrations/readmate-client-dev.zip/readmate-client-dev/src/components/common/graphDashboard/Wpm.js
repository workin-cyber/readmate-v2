import React from 'react'

export default function Wpm() {
  return (
    <div className='Tab'>Wpm</div>
  )
}
