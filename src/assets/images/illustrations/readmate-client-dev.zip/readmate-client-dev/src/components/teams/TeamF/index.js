// import NavBackButt from "../../common/NavBackButt/index";
// import CancelBtn from "../../common/cancelBtn";
// import DashboardBtn from "../../common/DashboardBtn";
// import TrueBtn from "../../common/trueBtn";
// import { NavBar } from "../../common/Nav";

// Creator : Team F-Oren
function TeamF() {
  return (
    <>
      {/* <CancelBtn />
      <DashboardBtn />
      <TrueBtn />
      <NavBackButt />
      <NavBar /> */}
    </>
  );
}

// export default TeamF;
