
function TeamB() {
    return (
        <div>TeamA</div>
    )
}

export default TeamB