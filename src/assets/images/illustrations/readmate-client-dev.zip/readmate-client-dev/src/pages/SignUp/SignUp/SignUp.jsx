import "./style.css";

import React from "react";

export const SignUp = () => {
  return <></>;
};

export default SignUp;
