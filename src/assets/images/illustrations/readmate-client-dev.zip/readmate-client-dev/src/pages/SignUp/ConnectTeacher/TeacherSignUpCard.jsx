import "./style.css";
// Creator : Team D - Ravid
function TeacherSignUpCard() {
  return (
    <div className="page">
      {/* <div className="card1"> */}
      <div className="card2">
        <h1>wellcome back!</h1>
        <form action="bla">
          <span>email ID</span>
          <input type="text" className="teacher_input"></input>
          <br></br>
          <input
            type="text"
            placeholder="password"
            className="teacher_input"
          ></input>
        </form>
        {/* </div> */}
      </div>
    </div>
  );
}

export default TeacherSignUpCard;
