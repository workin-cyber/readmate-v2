import styles from './style.module.css'
export default function SelectInput(props) {
  return (
    
        <>
      <fieldset>
        <select>
          <option value="0">Select The Reading Level</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
        </select>
      </fieldset>
        </>
    
  );
}
