
export default  ans = [
        {
            num: 1,
            ans: true
        },
        {
            num: 2,
            ans: false

        }, {
            num: 3,
            ans: true

        },
        {
            num: 4,
            ans: false

        },
        {
            num: 5,
            ans: false

        },
        {
            num: 6,
            ans: false

        },
        {
            num: 7,
            ans: false

        }
    ]