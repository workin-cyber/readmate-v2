import { BsTelephone } from "react-icons";

export function Contact() {
  return <></>;
}
