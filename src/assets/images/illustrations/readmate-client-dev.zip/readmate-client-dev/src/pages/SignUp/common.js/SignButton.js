import styles from './style.module.css'

export function SignButton() {
  return <button> Sign In</button>

}
